# OmniBible Design Direction

## Three Directions Considered

### Theme Name: Quiet Cathedral
A contemplative digital reading room inspired by warm paper, walnut, candlelight, and quiet editorial typography. The experience should feel reverent without becoming ornate.

**Probability:** 0.07

### Theme Name: Field Notes
A tactile study desk shaped by annotated margins, index cards, pencil marks, and archival blue. It turns Bible study into a calm, intelligent practice of collecting and connecting ideas.

**Probability:** 0.03

### Theme Name: Dawn on the Ridge
A luminous, nature-led reading experience with soft atmospheric landscapes, sunrise tones, and a spacious sense of hope. It uses imagery as an emotional pause between passages.

**Probability:** 0.09

## Chosen Approach: Field Notes

### Design Movement
Contemporary editorialism blended with analog research journals and library card catalogs.

### Core Principles
1. **Reading is the center.** Scripture remains the largest and quietest element on the screen.
2. **Tools stay close, never loud.** Study controls are discoverable through compact, tactile controls rather than dashboard clutter.
3. **Warm precision.** Every interaction should feel considered, archival, and calm.
4. **Personal traces matter.** Highlights, notes, and journals feel like a living margin around the text.

### Color Philosophy
A deep ink blue gives the app a sense of stillness and trust, while parchment, limestone, and muted cedar create the feeling of a beloved study desk. A single saffron-gold accent marks moments of attention—active verse, saved notes, or playback—without turning the experience into a bright productivity app. The signature brand color is **Margin Gold** `#D8A84E`.

### Layout Paradigm
A split reading-room composition: a slim archival rail on the left, a generous scripture column in the middle, and a contextual study margin on the right. On small screens, the rails fold into bottom sheets and the scripture column remains the primary surface.

### Signature Elements
- A small four-point “open book / compass” mark built from two offset chevrons.
- Hairline rules and index-style labels that make controls feel catalogued, not boxed.
- Parchment cards with subtle paper grain and a vertical saffron bookmark bar.

### Interaction Philosophy
Interactions should feel like turning a page or placing a note in a margin. Hover states lift elements by a few pixels, active states use Margin Gold, and panels reveal themselves from their nearest edge. No interaction should compete with the passage.

### Animation
Use short, soft ease-out transitions around 180–240ms. Verse focus fades in with a tiny vertical translation. Study panels slide from the right, audio controls rise from the bottom, and the ambient background shifts slowly but never distracts. Respect reduced-motion preferences.

### Typography System
Use **Cormorant Garamond** for scripture, chapter headings, and reflective editorial moments; use **DM Sans** for navigation, controls, metadata, and utility copy. Scripture should be generous and readable, with a 1.75 line-height. Utility labels use uppercase tracking at 0.14em sparingly.

### Brand Essence
**A private, beautiful study desk for anyone who wants to read Scripture slowly, understand it deeply, and carry it into daily life.** Personality: contemplative, generous, exacting.

### Brand Voice
Headlines are quietly confident. CTAs are invitations rather than commands. Microcopy is precise, warm, and never overly devotional or generic.

Example lines:
- “Read slowly. Notice more.”
- “Keep this thought in the margin.”

### Wordmark & Logo
The logo is a compact open-book compass: two narrow page shapes angle toward a central vertical spark, suggesting both Scripture and orientation. The wordmark uses a high-contrast serif “Omni” paired with a restrained sans “Bible,” but the symbol should stand alone in the app header and favicon.

### Signature Brand Color
**Margin Gold** `#D8A84E` — the color of a penciled underline catching afternoon light.

## Product Structure

The first delivery is a single-page reader workspace with functional local interactions: chapter navigation, translation selection, verse selection, study panel toggles, audio playback state, ambient mode, art mode, a journal note, and a responsive mobile layout. It uses representative John 1 content in the interface so the experience is immediately testable, while clearly labeling the translation and study metadata.

## Style Decisions

- Keep the main reading surface warm and light; use ink blue for navigation and study context.
- Prefer hairline separators, offset shadows, and paper-like surfaces over uniform rounded cards.
- Never use purple gradients, generic centered hero layouts, or Inter as the primary typeface.
- Keep the active passage and user intent visually dominant over secondary features.
