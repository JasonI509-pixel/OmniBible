# OmniBible Audio Removal Tasks

| Task | Status |
|---|---|
| Remove audio imports and speech state | Complete |
| Remove audio indicators and buttons | Complete |
| Remove the audio bottom panel and browser speech behavior | Complete |
| Verify the remaining reader, downloader, and Explain flows | Complete |
| Save a new checkpoint | In progress |

The public reader is now audio-free. Verse selection remains available for passage interaction and Explain syncing, but it no longer opens or triggers read-aloud controls.
