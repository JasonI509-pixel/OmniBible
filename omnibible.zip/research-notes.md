# Local Bible Data Findings

The OpenBible repository at https://github.com/churchstudio-org/openbible provides structured JSON with one directory per Bible version and a three-dimensional array shaped as book → chapter → verse. Its README states that KJV is public domain worldwide, while its generated translations are released under MIT; it explicitly avoids proprietary translations.

The Scrollmapper repository at https://github.com/scrollmapper/bible_databases lists 140 translations in multiple formats and has a full-book/chapter database workflow. Its repository license is MIT, but individual Bible texts still require their own source/licensing review.

Implementation decision: the frontend should bundle only text with clear compatible licensing, label each translation and language accurately, and avoid claiming unlimited language coverage when the text is not locally present. Runtime APIs are excluded per user request. Browser speech synthesis can provide read-aloud using voices installed on the visitor’s device; it is not a hosted AI narrator.

Important limitation: a truly AI-generated explanation or AI narration with no API and no bundled model cannot be delivered by a lightweight static frontend alone. The app can provide local deterministic explanation content and browser speech synthesis now, while leaving a clearly defined seam for a future bundled on-device model.
