/* Local content model: public reader, no account state, no runtime APIs. KJV text is bundled from OpenBible’s public-domain structured JSON. */
import kjv from "./kjv.json";
import portuguese from "./pt.json";
import japanese from "./ja.json";

export const BOOKS = [
  ["Genesis", 50], ["Exodus", 40], ["Leviticus", 27], ["Numbers", 36], ["Deuteronomy", 34], ["Joshua", 24], ["Judges", 21], ["Ruth", 4], ["1 Samuel", 31], ["2 Samuel", 24], ["1 Kings", 22], ["2 Kings", 25], ["1 Chronicles", 29], ["2 Chronicles", 36], ["Ezra", 10], ["Nehemiah", 13], ["Esther", 10], ["Job", 42], ["Psalms", 150], ["Proverbs", 31], ["Ecclesiastes", 12], ["Song of Solomon", 8], ["Isaiah", 66], ["Jeremiah", 52], ["Lamentations", 5], ["Ezekiel", 48], ["Daniel", 12], ["Hosea", 14], ["Joel", 3], ["Amos", 9], ["Obadiah", 1], ["Jonah", 4], ["Micah", 7], ["Nahum", 3], ["Habakkuk", 3], ["Zephaniah", 3], ["Haggai", 2], ["Zechariah", 14], ["Malachi", 4], ["Matthew", 28], ["Mark", 16], ["Luke", 24], ["John", 21], ["Acts", 28], ["Romans", 16], ["1 Corinthians", 16], ["2 Corinthians", 13], ["Galatians", 6], ["Ephesians", 6], ["Philippians", 4], ["Colossians", 4], ["1 Thessalonians", 5], ["2 Thessalonians", 3], ["1 Timothy", 6], ["2 Timothy", 4], ["Titus", 3], ["Philemon", 1], ["Hebrews", 13], ["James", 5], ["1 Peter", 5], ["2 Peter", 3], ["1 John", 5], ["2 John", 1], ["3 John", 1], ["Jude", 1], ["Revelation", 22],
] as const;

export const TRANSLATION_STYLES = [{ code: "KJV", name: "King James Version", availability: "bundled" }, { code: "GNB", name: "Good News Bible", availability: "not-bundled" }, { code: "HOLY", name: "Holy Bible", availability: "not-bundled" }, { code: "NLT", name: "New Living Translation", availability: "not-bundled" }, { code: "NLV", name: "New Life Version", availability: "not-bundled" }];
export const LOCAL_LANGUAGES = [{ code: "en", label: "English", dataset: "KJV", available: true }, { code: "pt", label: "Português", dataset: "PT", available: true }, { code: "ja", label: "日本語", dataset: "JA", available: true }, { code: "es", label: "Español", dataset: "", available: false }, { code: "fr", label: "Français", dataset: "", available: false }, { code: "de", label: "Deutsch", dataset: "", available: false }, { code: "zh", label: "中文", dataset: "", available: false }];
export const LOCAL_TRANSLATIONS = TRANSLATION_STYLES.filter((item) => item.availability === "bundled");

export type BibleChapter = string[];
export const KJV = kjv as BibleChapter[][];
export const PT = portuguese as BibleChapter[][];
export const JA = japanese as BibleChapter[][];
export const getBookIndex = (name: string) => BOOKS.findIndex(([book]) => book === name);
const getSource = (version: string) => version === "PT" ? PT : version === "JA" ? JA : KJV;
export const getChapter = (book: string, chapter: number, version = "KJV"): BibleChapter => getSource(version)[getBookIndex(book)]?.[chapter - 1] ?? [];
export const getBook = (book: string, version = "KJV") => getSource(version)[getBookIndex(book)] ?? [];
export const getTestament = (testament: "Old" | "New", version = "KJV") => { const source = getSource(version); const start = testament === "Old" ? 0 : 39; const end = testament === "Old" ? 39 : 66; return source.slice(start, end); };
