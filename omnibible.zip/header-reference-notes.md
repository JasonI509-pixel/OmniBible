# Header Reference Notes

The supplied reference image is 367 × 116 pixels and shows four right-side utility elements in order: search icon, sliders/settings icon, help icon, and a pale circular avatar labeled “AB.” The requested cleanup is to remove these utility controls from OmniBible rather than reproduce them.

The language/translation controls should remain in the reading toolbar because the earlier reference separately showed a wide EN selector and a KJV selector. The new toolbar will add structured Explain selectors and a download action while keeping the header quiet.
