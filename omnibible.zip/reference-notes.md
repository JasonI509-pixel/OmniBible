# Reference and Scope Notes

The provided 564 × 137 reference shows a compact control row: a wide language selector labeled “EN,” a translation selector labeled “KJV” with a gold active underline, then icon controls. The selectors are visually distinct, rectangular, lightly bordered, and aligned on one baseline.

The public reader should keep language and translation as independent values. A translation style changes wording and pronunciation within its supported language; a language choice changes the rendered language while the chosen style remains conceptually separate. Only text that is locally bundled and legally compatible can be presented as real Scripture. Newly generated language drafts must be labeled as drafts and not represented as authoritative translations.

Printing should use a dedicated print scope control with Verse, Chapter, Book, and Testament options, and `window.print()` with print CSS should hide app chrome and show only the selected scope.

The current UI already removes Bookmarks and Reading history from the side navigation, but it still contains recent-passage and My Library language that should also be removed to keep the public experience stateless. The brand request is for a Bible with an angel; this should be implemented as a simple symbolic icon rather than an attempt to depict doctrine as fact.
